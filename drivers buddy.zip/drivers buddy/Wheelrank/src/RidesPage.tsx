import React, { useState } from 'react';
import { 
  Car, 
  Search, 
  Filter, 
  Download, 
  Calendar,
  MapPin,
  Clock,
  ChevronRight,
  MoreHorizontal,
  Plus,
  X,
  Navigation
} from 'lucide-react';
import { Sidebar, type Page } from './components/Navigation';
import { cn } from './lib/utils';
import { type Ride } from './data/rides';

interface RidesPageProps {
  onNavigate: (p: Page) => void;
  rides: Ride[];
  onAddRide: (ride: Ride) => void;
}

export default function RidesPage({ onNavigate, rides, onAddRide }: RidesPageProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newRide, setNewRide] = useState({
    from: '',
    to: '',
    miles: '',
    category: 'Business',
    purpose: 'Meeting'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date();
    const dateStr = `${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}-${now.getFullYear()} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    onAddRide({
      start: dateStr,
      end: dateStr, // Simplified for now
      from: newRide.from,
      to: newRide.to,
      miles: parseFloat(newRide.miles),
      category: newRide.category,
      purpose: newRide.purpose
    });
    
    setIsModalOpen(false);
    setNewRide({ from: '', to: '', miles: '', category: 'Business', purpose: 'Meeting' });
  };

  return (
    <div className="min-h-screen bg-background-dark text-slate-100 flex">
      <Sidebar currentPage="rides" onPageChange={onNavigate} />
      
      <main className="flex-1 p-8 overflow-y-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white">Ride History</h1>
            <p className="text-slate-400">Manage and review your driving logs and trip data.</p>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 bg-primary px-4 py-2 rounded-lg text-sm font-bold text-white hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
            >
              <Plus className="w-4 h-4" />
              Log New Trip
            </button>
            <button className="flex items-center gap-2 bg-surface-dark px-4 py-2 rounded-lg border border-surface-darker text-sm font-medium hover:bg-surface-darker transition-colors">
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          </div>
        </header>

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-surface-dark border border-surface-darker w-full max-w-md rounded-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
              <div className="p-6 border-b border-surface-darker flex justify-between items-center">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Navigation className="w-5 h-5 text-primary" />
                  Log New Trip
                </h2>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-surface-darker rounded-full text-slate-400">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Starting Point</label>
                  <input 
                    required
                    type="text" 
                    value={newRide.from}
                    onChange={e => setNewRide({...newRide, from: e.target.value})}
                    placeholder="e.g. Fort Pierce"
                    className="w-full bg-background-dark border border-surface-darker rounded-lg px-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Destination</label>
                  <input 
                    required
                    type="text" 
                    value={newRide.to}
                    onChange={e => setNewRide({...newRide, to: e.target.value})}
                    placeholder="e.g. West Palm Beach"
                    className="w-full bg-background-dark border border-surface-darker rounded-lg px-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Distance (Miles)</label>
                    <input 
                      required
                      type="number" 
                      step="0.1"
                      value={newRide.miles}
                      onChange={e => setNewRide({...newRide, miles: e.target.value})}
                      placeholder="0.0"
                      className="w-full bg-background-dark border border-surface-darker rounded-lg px-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase">Category</label>
                    <select 
                      value={newRide.category}
                      onChange={e => setNewRide({...newRide, category: e.target.value})}
                      className="w-full bg-background-dark border border-surface-darker rounded-lg px-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
                    >
                      <option value="Business">Business</option>
                      <option value="Personal">Personal</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Purpose</label>
                  <input 
                    type="text" 
                    value={newRide.purpose}
                    onChange={e => setNewRide({...newRide, purpose: e.target.value})}
                    placeholder="e.g. Meeting"
                    className="w-full bg-background-dark border border-surface-darker rounded-lg px-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-bold rounded-xl shadow-lg shadow-primary/20 transition-all mt-4"
                >
                  Save Trip to History
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Filters & Search */}
        <div className="bg-surface-dark p-4 rounded-xl border border-surface-darker mb-8 flex flex-wrap gap-4 items-center justify-between">
          <div className="flex gap-4 items-center flex-1 min-w-[300px]">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search locations or purpose..." 
                className="w-full bg-background-dark border border-surface-darker rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
              />
            </div>
            <button className="flex items-center gap-2 bg-background-dark border border-surface-darker px-4 py-2 rounded-lg text-sm hover:bg-surface-darker transition-colors">
              <Filter className="w-4 h-4" />
              Filters
            </button>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold">All Rides</button>
            <button className="px-4 py-2 bg-surface-darker text-slate-400 rounded-lg text-sm font-medium hover:text-white transition-colors">Business</button>
            <button className="px-4 py-2 bg-surface-darker text-slate-400 rounded-lg text-sm font-medium hover:text-white transition-colors">Personal</button>
          </div>
        </div>

        {/* Rides Table */}
        <div className="bg-surface-dark rounded-xl border border-surface-darker overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-500 text-xs border-b border-surface-darker uppercase tracking-wider">
                  <th className="p-6 font-medium">Trip Details</th>
                  <th className="p-6 font-medium">Category</th>
                  <th className="p-6 font-medium">Distance</th>
                  <th className="p-6 font-medium">Purpose</th>
                  <th className="p-6 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-darker/50">
                {rides.map((ride, i) => (
                  <tr key={i} className="hover:bg-white/5 transition-colors group animate-in slide-in-from-top-2 duration-300">
                    <td className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-primary/10 rounded-xl mt-1">
                          <Car className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-bold text-slate-100">{ride.from}</span>
                            <ChevronRight className="w-3 h-3 text-slate-600" />
                            <span className="font-bold text-slate-100">{ride.to}</span>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {ride.start.split(' ')[0]}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {ride.start.split(' ')[1]}
                            </span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="p-6">
                      <span className={cn(
                        "px-3 py-1 text-[10px] font-bold rounded-full uppercase tracking-wider",
                        ride.category === 'Business' ? "bg-primary/10 text-primary border border-primary/20" : "bg-accent-green/10 text-accent-green border border-accent-green/20"
                      )}>
                        {ride.category}
                      </span>
                    </td>
                    <td className="p-6">
                      <p className="text-lg font-black text-white">{ride.miles}</p>
                      <p className="text-[10px] text-slate-500 uppercase font-bold">Miles</p>
                    </td>
                    <td className="p-6">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-slate-300">{ride.purpose || 'General Drive'}</span>
                      </div>
                    </td>
                    <td className="p-6 text-right">
                      <button className="p-2 text-slate-500 hover:text-white hover:bg-surface-darker rounded-lg transition-all">
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
