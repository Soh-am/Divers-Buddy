import React from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  Zap, 
  Trophy, 
  Car, 
  ArrowRight, 
  CheckCircle2, 
  Globe, 
  MessageSquare, 
  Rss,
  Activity,
  Award,
  Settings,
  Bell,
  Lock,
  LayoutDashboard
} from 'lucide-react';
import { type Page } from './components/Navigation';

export default function LandingPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <div className="min-h-screen bg-background-dark text-slate-100">
      {/* Nav */}
      <nav className="fixed top-0 z-50 w-full border-b border-slate-800 bg-background-dark/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <Zap className="text-primary w-8 h-8" />
              <span className="text-xl font-bold tracking-tight">WheelRank</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a className="text-sm font-medium hover:text-primary transition-colors" href="#">Features</a>
              <a className="text-sm font-medium hover:text-primary transition-colors" href="#">Leaderboard</a>
              <a className="text-sm font-medium hover:text-primary transition-colors" href="#">Vehicle Health</a>
              <a className="text-sm font-medium hover:text-primary transition-colors" href="#">Rewards</a>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => onNavigate('driver')}
                className="px-4 py-2 text-sm font-bold bg-primary hover:bg-primary/90 text-white rounded-lg transition-all shadow-lg shadow-primary/20"
              >
                Login as Driver
              </button>
              <button 
                onClick={() => onNavigate('personal')}
                className="hidden sm:block px-4 py-2 text-sm font-bold bg-slate-800 hover:bg-slate-700 rounded-lg transition-all"
              >
                Dashboard
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-16">
        {/* Hero */}
        <section className="relative overflow-hidden py-20 lg:py-32">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none -z-10">
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px]"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-accent-green/10 rounded-full blur-[100px]"></div>
          </div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex flex-col gap-8"
              >
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 w-fit">
                  <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
                  <span className="text-xs font-bold text-primary uppercase tracking-wider">AI-Powered Performance</span>
                </div>
                <h1 className="text-5xl lg:text-7xl font-bold leading-tight tracking-tight text-white">
                  Drive Smart.<br />Drive Safe.<br /><span className="text-primary">Earn Rewards.</span>
                </h1>
                <p className="text-lg text-slate-400 max-w-lg leading-relaxed">
                  Experience the future of driving with WheelRank's AI-powered vehicle health monitoring and performance tracking platform. Connect your car and start optimizing today.
                </p>
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => onNavigate('driver')}
                    className="flex items-center justify-center gap-2 min-w-[180px] h-14 bg-primary text-white font-bold rounded-xl shadow-xl shadow-primary/25 hover:scale-105 transition-transform"
                  >
                    <Zap className="w-5 h-5" />
                    Login as Driver
                  </button>
                  <button 
                    onClick={() => onNavigate('personal')}
                    className="flex items-center justify-center gap-2 min-w-[180px] h-14 bg-slate-800 border border-slate-700 font-bold rounded-xl hover:bg-slate-700 transition-all"
                  >
                    <LayoutDashboard className="w-5 h-5" />
                    Personal Dashboard
                  </button>
                </div>
                <div className="flex items-center gap-6 pt-4">
                  <div className="flex -space-x-3">
                    {[1, 2, 3].map((i) => (
                      <img 
                        key={i}
                        className="h-10 w-10 rounded-full border-2 border-background-dark" 
                        src={`https://picsum.photos/seed/user${i}/100/100`}
                        referrerPolicy="no-referrer"
                      />
                    ))}
                    <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-background-dark bg-slate-800 text-xs font-bold text-white">+12k</div>
                  </div>
                  <p className="text-sm text-slate-500 font-medium">Joined by 12,000+ active drivers</p>
                </div>
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative group"
              >
                <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent-green opacity-25 blur-2xl group-hover:opacity-40 transition-opacity"></div>
                <div className="relative bg-slate-900 rounded-2xl border border-slate-800 p-2 overflow-hidden shadow-2xl">
                  <div 
                    className="aspect-[4/3] w-full rounded-xl bg-center bg-cover" 
                    style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDCVbJneMLbeuSPNQBJ9Uf0kjTkDhcBQVuA3iuk3z-GMLZJBiBD3VOZQs7rmw5vX9NGB2Fy_XYBZmmShl1t-XhOTHzkXFc_PWc2Aox1jNm08eL_NXPHm3NEV6OqmxTfPX0NgWezbke3JmdBFWg8b3RMVLxVyX1QGf946ZePAAulnXnQ6C47DpMwrQEmIj1Zvu4uYBxYjzVhN8QQiVAoFiUWc54wlI68uOQnKtG5tzFlbmqi-EEUT-tDL80AOWfav4wjm-Gw2zRVe9JC')" }}
                  ></div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-12 border-y border-slate-800 bg-slate-900/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { label: 'Active Drivers', value: '12k+' },
                { label: 'Miles Tracked', value: '5.2M' },
                { label: 'Safety Score Avg', value: '88/100' },
                { label: 'Rewards Paid', value: '$2.4M' },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="text-primary text-3xl font-bold">{stat.value}</p>
                  <p className="text-sm text-slate-500 mt-1 uppercase tracking-wider font-semibold">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl font-bold tracking-tight">Advanced Driving Intelligence</h2>
            <p className="text-slate-500 max-w-2xl mx-auto text-lg">Our AI-driven platform monitors every aspect of your journey to ensure safety, efficiency, and maximum reward potential.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Activity, title: 'AI Wheel Score', desc: 'Proprietary algorithms analyze your acceleration, braking, and cornering patterns in real-time to provide a safety score.' },
              { icon: Trophy, title: 'Driver Leaderboard', desc: 'Compete with drivers globally or in your region. Climb the rankings to unlock exclusive insurance tiers and digital rewards.' },
              { icon: Settings, title: 'Health Monitoring', desc: 'Get predictive maintenance alerts before parts fail. Monitor engine telemetry, battery health, and fluid levels directly from your phone.' },
              { icon: ShieldCheck, title: 'Emission Tracking', desc: "Reduce your carbon footprint with eco-driving tips. Track your CO2 output and earn 'Green Miles' for sustainable driving habits." },
              { icon: Bell, title: 'Insurance Reminders', desc: 'Never miss a renewal. Our system automatically scans your documents and alerts you to upcoming deadlines and lower rates.' },
              { icon: Lock, title: 'Secure Data Privacy', desc: 'Your data is encrypted and owned by you. Choose what you share with insurers and third parties for total control over your privacy.' },
            ].map((feature) => (
              <div key={feature.title} className="glass-panel p-8 rounded-2xl flex flex-col gap-6 hover:border-primary/50 transition-colors group">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <feature.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-slate-400 leading-relaxed">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 relative overflow-hidden">
          <div className="max-w-4xl mx-auto px-4 text-center space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold leading-tight">Ready to transform your drive?</h2>
            <p className="text-xl text-slate-400">Join thousands of smart drivers who are saving money and improving vehicle longevity with WheelRank.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => onNavigate('personal')}
                className="px-10 py-4 bg-primary text-white text-lg font-bold rounded-xl shadow-xl shadow-primary/30 hover:scale-105 transition-all"
              >
                Get Started Free
              </button>
              <button className="px-10 py-4 border border-slate-700 text-lg font-bold rounded-xl hover:bg-slate-800 transition-all">Contact Sales</button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-12">
            <div className="col-span-2 md:col-span-1 space-y-6">
              <div className="flex items-center gap-2">
                <Zap className="text-primary w-8 h-8" />
                <span className="text-xl font-bold tracking-tight text-white">WheelRank</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">The world's leading AI-powered platform for smart driving and vehicle health metrics. Built for the modern driver.</p>
              <div className="flex gap-4">
                <a className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-all" href="#"><Globe className="w-5 h-5" /></a>
                <a className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-all" href="#"><MessageSquare className="w-5 h-5" /></a>
                <a className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-all" href="#"><Rss className="w-5 h-5" /></a>
              </div>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">Platform</h4>
              <ul className="space-y-4 text-sm text-slate-400">
                <li><a className="hover:text-primary transition-colors" href="#">Safety Score</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Leaderboards</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">API Integration</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Rewards Engine</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">Company</h4>
              <ul className="space-y-4 text-sm text-slate-400">
                <li><a className="hover:text-primary transition-colors" href="#">About Us</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Careers</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Security</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">Subscribe</h4>
              <p className="text-slate-400 text-sm mb-4">Get the latest driving tips and tech updates.</p>
              <form className="flex gap-2">
                <input className="bg-slate-800 border-none rounded-lg flex-1 text-sm focus:ring-1 focus:ring-primary text-white p-2" placeholder="Email" type="email" />
                <button className="bg-primary p-2 rounded-lg text-white">
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
          <div className="mt-16 pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <p>© 2024 WheelRank SaaS Platform. All rights reserved.</p>
            <div className="flex gap-6">
              <a className="hover:text-white" href="#">Privacy Policy</a>
              <a className="hover:text-white" href="#">Terms of Service</a>
              <a className="hover:text-white" href="#">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
