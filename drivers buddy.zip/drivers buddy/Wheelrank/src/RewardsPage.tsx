import React, { useState } from 'react';
import { 
  Gift, 
  Ticket, 
  Copy, 
  Check, 
  Fuel, 
  Utensils, 
  Wrench, 
  Coffee, 
  ShoppingBag,
  Clock,
  Info
} from 'lucide-react';
import { Sidebar, type Page } from './components/Navigation';
import { cn } from './lib/utils';

interface Coupon {
  id: string;
  title: string;
  description: string;
  code: string;
  expiry: string;
  category: string;
  icon: React.ElementType;
  color: string;
}

const dummyCoupons: Coupon[] = [
  {
    id: '1',
    title: '20% OFF Fuel',
    description: 'Get 20% discount on your next 10 gallons at any Shell station.',
    code: 'SHELL20OFF',
    expiry: '2026-03-15',
    category: 'Fuel',
    icon: Fuel,
    color: 'from-blue-600 to-indigo-600'
  },
  {
    id: '2',
    title: '$15 Food Voucher',
    description: 'Valid at all participating drive-thru partners including McDonald\'s and Subway.',
    code: 'DRIVEFOOD15',
    expiry: '2026-03-20',
    category: 'Food',
    icon: Utensils,
    color: 'from-emerald-600 to-teal-600'
  },
  {
    id: '3',
    title: 'Free Oil Change',
    description: 'Elite Tier Maintenance Reward. Valid at any authorized service center.',
    code: 'MAINTFREE26',
    expiry: '2026-04-01',
    category: 'Maintenance',
    icon: Wrench,
    color: 'from-purple-600 to-violet-600'
  },
  {
    id: '4',
    title: 'Free Starbucks Coffee',
    description: 'Start your morning right. One free grande coffee of your choice.',
    code: 'COFFEEBREAK',
    expiry: '2026-03-10',
    category: 'Lifestyle',
    icon: Coffee,
    color: 'from-orange-500 to-red-500'
  },
  {
    id: '5',
    title: '10% Amazon Gift Card',
    description: 'Redeem for a 10% discount on any automotive accessories on Amazon.',
    code: 'AMZAUTO10',
    expiry: '2026-05-15',
    category: 'Shopping',
    icon: ShoppingBag,
    color: 'from-slate-700 to-slate-900'
  }
];

export default function RewardsPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen bg-background-dark text-slate-100 flex">
      <Sidebar currentPage="rewards" onPageChange={onNavigate} />
      
      <main className="flex-1 p-8 overflow-y-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Driver Rewards</h1>
            <p className="text-slate-400">Exclusive perks and coupons earned through safe driving.</p>
          </div>
          <div className="flex items-center gap-3 px-4 py-2 bg-primary/10 border border-primary/20 rounded-lg text-primary">
            <Gift className="w-5 h-5" />
            <span className="font-bold text-sm">2,450 Points Available</span>
          </div>
        </header>

        {/* Rewards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {dummyCoupons.map((coupon) => (
            <div key={coupon.id} className="bg-surface-dark rounded-2xl border border-surface-darker overflow-hidden flex flex-col shadow-lg hover:shadow-primary/5 transition-all group">
              {/* Top Section with Gradient */}
              <div className={cn("p-6 text-white bg-gradient-to-br relative overflow-hidden", coupon.color)}>
                <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
                  <coupon.icon className="w-24 h-24" />
                </div>
                <div className="relative z-10">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                      <coupon.icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-bold bg-black/20 px-2 py-1 rounded-full uppercase tracking-wider backdrop-blur-sm">
                      {coupon.category}
                    </span>
                  </div>
                  <h3 className="text-2xl font-black mb-1">{coupon.title}</h3>
                  <div className="flex items-center gap-1 text-xs opacity-80">
                    <Clock className="w-3 h-3" />
                    Expires: {coupon.expiry}
                  </div>
                </div>
              </div>

              {/* Bottom Section */}
              <div className="p-6 flex-1 flex flex-col">
                <p className="text-sm text-slate-400 mb-6 leading-relaxed">
                  {coupon.description}
                </p>
                
                <div className="mt-auto space-y-4">
                  <div className="flex items-center gap-2 p-3 bg-background-dark rounded-xl border border-dashed border-slate-700 group-hover:border-primary/50 transition-colors">
                    <Ticket className="w-4 h-4 text-slate-500" />
                    <span className="flex-1 font-mono font-bold text-lg tracking-wider text-center">{coupon.code}</span>
                    <button 
                      onClick={() => copyToClipboard(coupon.code, coupon.id)}
                      className="p-2 hover:bg-white/5 rounded-lg text-slate-400 hover:text-primary transition-all"
                      title="Copy Code"
                    >
                      {copiedId === coupon.id ? <Check className="w-4 h-4 text-accent-green" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  
                  <button className="w-full py-3 bg-primary hover:bg-primary/90 text-white font-bold rounded-xl transition-all shadow-lg shadow-primary/10 flex items-center justify-center gap-2">
                    Redeem Now
                  </button>
                  
                  <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 uppercase font-bold tracking-tighter">
                    <Info className="w-3 h-3" />
                    Terms and conditions apply
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
