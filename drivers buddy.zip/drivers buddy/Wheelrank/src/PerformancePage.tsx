import React from 'react';
import { 
  History, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  DollarSign, 
  Gauge, 
  Activity,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  Clock
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip,
  LineChart,
  Line
} from 'recharts';
import { Sidebar, type Page } from './components/Navigation';
import { cn } from './lib/utils';

const earningData = [
  { day: 'Mon', amount: 120 },
  { day: 'Tue', amount: 150 },
  { day: 'Wed', amount: 110 },
  { day: 'Thu', amount: 180 },
  { day: 'Fri', amount: 240 },
  { day: 'Sat', amount: 310 },
  { day: 'Sun', amount: 280 },
];

const speedConsistencyData = [
  { time: '08:00', speed: 45, limit: 40 },
  { time: '09:00', speed: 42, limit: 40 },
  { time: '10:00', speed: 38, limit: 40 },
  { time: '11:00', speed: 40, limit: 40 },
  { time: '12:00', speed: 41, limit: 40 },
  { time: '13:00', speed: 44, limit: 40 },
  { time: '14:00', speed: 39, limit: 40 },
];

const consistencyMetrics = [
  { label: 'Braking Consistency', value: 94, status: 'Excellent', color: 'text-accent-green' },
  { label: 'Acceleration Smoothness', value: 88, status: 'Good', color: 'text-primary' },
  { label: 'Cornering Stability', value: 91, status: 'Excellent', color: 'text-accent-green' },
  { label: 'Lane Discipline', value: 85, status: 'Good', color: 'text-primary' },
];

export default function PerformancePage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <div className="min-h-screen bg-background-dark text-slate-100 flex">
      <Sidebar currentPage="performance" onPageChange={onNavigate} />
      
      <main className="flex-1 p-8 overflow-y-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Performance Analytics</h1>
            <p className="text-slate-400">In-depth analysis of your reliability, consistency, and earnings.</p>
          </div>
          <div className="flex gap-4">
            <div className="bg-surface-dark px-4 py-2 rounded-lg border border-surface-darker flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <span className="text-sm font-medium">Last 7 Days</span>
            </div>
          </div>
        </header>

        {/* Top Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-primary/10 rounded-lg text-primary">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <span className="text-accent-green text-xs font-bold">+2.4%</span>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider">Reliability Score</p>
            <h3 className="text-3xl font-black mt-1">98.2%</h3>
            <p className="text-[10px] text-slate-500 mt-2">Based on trip completion & punctuality</p>
          </div>

          <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-accent-green/10 rounded-lg text-accent-green">
                <Zap className="w-5 h-5" />
              </div>
              <span className="text-accent-green text-xs font-bold">+5.1%</span>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider">Consistency Index</p>
            <h3 className="text-3xl font-black mt-1">92.5</h3>
            <p className="text-[10px] text-slate-500 mt-2">Stability of driving patterns</p>
          </div>

          <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-yellow-500/10 rounded-lg text-yellow-500">
                <DollarSign className="w-5 h-5" />
              </div>
              <span className="text-accent-green text-xs font-bold">+12.8%</span>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider">Total Earnings</p>
            <h3 className="text-3xl font-black mt-1">$1,490</h3>
            <p className="text-[10px] text-slate-500 mt-2">Net earnings this week</p>
          </div>

          <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500">
                <Gauge className="w-5 h-5" />
              </div>
              <span className="text-slate-500 text-xs font-bold">Stable</span>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider">Avg Speed Stability</p>
            <h3 className="text-3xl font-black mt-1">96%</h3>
            <p className="text-[10px] text-slate-500 mt-2">Adherence to speed limits</p>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6 mb-8">
          {/* Earning Performance */}
          <div className="col-span-12 lg:col-span-8 bg-surface-dark rounded-xl p-6 border border-surface-darker">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                Weekly Earning Performance
              </h3>
              <div className="flex gap-2">
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-primary"></div> Earnings
                </span>
              </div>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={earningData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="day" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                    itemStyle={{ color: '#fff' }}
                  />
                  <Bar dataKey="amount" fill="#0da6f2" radius={[4, 4, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Reliability Metrics */}
          <div className="col-span-12 lg:col-span-4 bg-surface-dark rounded-xl p-6 border border-surface-darker">
            <h3 className="font-bold mb-6 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-accent-green" />
              Reliability Metrics
            </h3>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-400">Trip Completion Rate</span>
                  <span className="font-bold text-white">99.8%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-accent-green h-full w-[99.8%]"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-400">On-Time Arrival</span>
                  <span className="font-bold text-white">96.5%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-primary h-full w-[96.5%]"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-400">Customer Rating</span>
                  <span className="font-bold text-white">4.92 / 5.0</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-yellow-500 h-full w-[98%]"></div>
                </div>
              </div>
              <div className="pt-4 border-t border-surface-darker">
                <div className="flex items-center gap-3 p-3 bg-accent-green/5 rounded-lg border border-accent-green/10">
                  <ShieldCheck className="w-5 h-5 text-accent-green" />
                  <div>
                    <p className="text-xs font-bold text-white">Elite Reliability Status</p>
                    <p className="text-[10px] text-slate-400">You are in the top 1% of reliable drivers.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Average Speed Consistency */}
          <div className="col-span-12 lg:col-span-7 bg-surface-dark rounded-xl p-6 border border-surface-darker">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold flex items-center gap-2">
                <Activity className="w-4 h-4 text-purple-500" />
                Average Speed Consistency
              </h3>
              <div className="flex gap-4">
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-purple-500"></div> Avg Speed
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-slate-600"></div> Speed Limit
                </span>
              </div>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={speedConsistencyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="time" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                    itemStyle={{ color: '#fff' }}
                  />
                  <Line type="monotone" dataKey="speed" stroke="#a855f7" strokeWidth={3} dot={{ r: 4, fill: '#a855f7' }} activeDot={{ r: 6 }} />
                  <Line type="monotone" dataKey="limit" stroke="#475569" strokeDasharray="5 5" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Consistency Metrics List */}
          <div className="col-span-12 lg:col-span-5 bg-surface-dark rounded-xl p-6 border border-surface-darker">
            <h3 className="font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Driving Consistency Metrics
            </h3>
            <div className="space-y-4">
              {consistencyMetrics.map((metric, i) => (
                <div key={i} className="p-4 bg-background-dark/50 rounded-xl border border-surface-darker flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">{metric.label}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-2xl font-black text-white">{metric.value}%</span>
                      <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded uppercase", metric.color.replace('text-', 'bg-') + '/10', metric.color)}>
                        {metric.status}
                      </span>
                    </div>
                  </div>
                  <div className="w-12 h-12 rounded-full border-4 border-slate-800 flex items-center justify-center relative">
                    <svg className="w-full h-full -rotate-90">
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        fill="transparent"
                        stroke="currentColor"
                        strokeWidth="4"
                        strokeDasharray={`${metric.value * 1.25} 125`}
                        className={metric.color}
                      />
                    </svg>
                    <TrendingUp className={cn("w-4 h-4 absolute", metric.color)} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
