import React, { useState } from 'react';
import LandingPage from './LandingPage';
import PersonalDashboard from './PersonalDashboard';
import DriverDashboard from './DriverDashboard';
import RidesPage from './RidesPage';
import PerformancePage from './PerformancePage';
import RewardsPage from './RewardsPage';
import { type Page } from './components/Navigation';
import { ridesData as initialRides, type Ride } from './data/rides';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [rides, setRides] = useState<Ride[]>(initialRides);

  const addRide = (newRide: Ride) => {
    setRides(prev => [newRide, ...prev]);
  };

  const navigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-background-dark font-sans">
      {currentPage === 'landing' && <LandingPage onNavigate={navigate} />}
      {currentPage === 'personal' && <PersonalDashboard onNavigate={navigate} />}
      {currentPage === 'driver' && <DriverDashboard onNavigate={navigate} rides={rides} onAddRide={addRide} />}
      {currentPage === 'rides' && <RidesPage onNavigate={navigate} rides={rides} onAddRide={addRide} />}
      {currentPage === 'performance' && <PerformancePage onNavigate={navigate} />}
      {currentPage === 'rewards' && <RewardsPage onNavigate={navigate} />}
    </div>
  );
}
