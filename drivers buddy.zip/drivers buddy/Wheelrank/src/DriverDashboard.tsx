import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Milestone, 
  History, 
  Verified, 
  Bell, 
  Navigation as NavIcon, 
  X,
  Fuel,
  Utensils,
  Wrench,
  AlertTriangle,
  BrainCircuit,
  Play,
  RefreshCw,
  Sliders,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { Sidebar, type Page } from './components/Navigation';
import { cn } from './lib/utils';
import { predictionService, DrivingMetrics } from './services/predictionService';
import { type Ride } from './data/rides';
import { Plus } from 'lucide-react';

const behaviorData = [
  { name: '1', g: 80 },
  { name: '2', g: 70 },
  { name: '3', g: 75 },
  { name: '4', g: 60 },
  { name: '5', g: 70 },
  { name: '6', g: 50 },
  { name: '7', g: 65 },
];

const scoreData = [
  { name: 'Score', value: 88 },
  { name: 'Remaining', value: 12 },
];

const alerts = [
  { speed: '84 km/h', zone: 'in 60 zone', loc: 'Lexington Ave', time: '14:20 PM', type: 'critical' },
  { speed: '65 km/h', zone: 'in 50 zone', loc: 'Broadway St', time: '11:05 AM', type: 'warning' },
  { speed: '72 km/h', zone: 'in 60 zone', loc: 'Park West Dr', time: '09:12 AM', type: 'warning' },
];

const leaderboard = [
  { rank: '#1', name: 'Marcus Chen', score: 98, rides: '2,140', status: 'Elite', color: 'text-primary' },
  { rank: '#2', name: 'Elena Rodriguez', score: 96, rides: '1,892', status: 'Pro', color: 'text-slate-400' },
  { rank: '#12', name: 'Alex Driver (You)', score: 88, rides: '1,240', status: 'Pro', color: 'text-primary', active: true },
];

interface DriverDashboardProps {
  onNavigate: (p: Page) => void;
  rides: Ride[];
  onAddRide: (ride: Ride) => void;
}

export default function DriverDashboard({ onNavigate, rides, onAddRide }: DriverDashboardProps) {
  const [metrics, setMetrics] = useState<DrivingMetrics>({
    braking: 88,
    acceleration: 94,
    corners: 91,
    overspeedAlerts: 3,
    avgGForce: 1.2
  });
  
  const [predictedScore, setPredictedScore] = useState(88);
  const [isSimulating, setIsSimulating] = useState(false);
  const [showManual, setShowManual] = useState(false);

  const handleMetricChange = (key: keyof DrivingMetrics, value: number) => {
    const newMetrics = { ...metrics, [key]: value };
    setMetrics(newMetrics);
    const score = predictionService.predictWheelScore(newMetrics);
    setPredictedScore(score);
  };

  const handleSimulate = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const newMetrics = predictionService.generateRandomMetrics();
      const score = predictionService.predictWheelScore(newMetrics);
      setMetrics(newMetrics);
      setPredictedScore(score);
      setIsSimulating(false);
    }, 1500);
  };

  const scoreData = [
    { name: 'Score', value: predictedScore },
    { name: 'Remaining', value: 100 - predictedScore },
  ];

  return (
    <div className="min-h-screen bg-background-dark text-slate-100 flex">
      <Sidebar currentPage="driver" onPageChange={onNavigate} />
      
      <main className="flex-1 p-8 overflow-y-auto">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Driver Dashboard</h1>
            <p className="text-slate-400">Welcome back, Alex. Your safety score is up 5% this week.</p>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={() => onNavigate('rides')}
              className="flex items-center gap-2 bg-primary px-4 py-2 rounded-lg text-sm font-bold text-white hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
            >
              <Plus className="w-4 h-4" />
              Log Trip
            </button>
            <button 
              onClick={handleSimulate}
              disabled={isSimulating}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg border transition-all",
                isSimulating ? "bg-slate-800 border-slate-700 text-slate-500" : "bg-primary/10 border-primary/20 text-primary hover:bg-primary/20"
              )}
            >
              {isSimulating ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Play className="w-4 h-4" />
              )}
              {isSimulating ? "Analyzing Drive..." : "Simulate New Drive"}
            </button>
            <div className="flex items-center gap-2 bg-surface-dark px-4 py-2 rounded-lg border border-surface-darker">
              <Verified className="w-5 h-5 text-accent-green" />
              <span className="font-bold text-accent-green">Pro Rank</span>
            </div>
            <div className="bg-surface-dark p-2 rounded-lg border border-surface-darker cursor-pointer">
              <Bell className="w-5 h-5" />
            </div>
          </div>
        </header>

        {/* Top Grid */}
        <div className="grid grid-cols-12 gap-6 mb-6">
          {/* Manual Tuning Panel */}
          <div className="col-span-12 bg-surface-dark rounded-xl border border-surface-darker overflow-hidden">
            <button 
              onClick={() => setShowManual(!showManual)}
              className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Sliders className="w-5 h-5 text-primary" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold">Manual Parameter Tuning</h3>
                  <p className="text-xs text-slate-500">Adjust driving metrics to see AI score predictions in real-time</p>
                </div>
              </div>
              {showManual ? <ChevronUp className="w-5 h-5 text-slate-500" /> : <ChevronDown className="w-5 h-5 text-slate-500" />}
            </button>
            
            {showManual && (
              <div className="p-6 border-t border-surface-darker bg-black/20">
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Braking</label>
                      <span className="text-xs font-mono text-primary">{Math.round(metrics.braking)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="100" 
                      value={metrics.braking} 
                      onChange={(e) => handleMetricChange('braking', parseInt(e.target.value))}
                      className="w-full accent-primary h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Acceleration</label>
                      <span className="text-xs font-mono text-primary">{Math.round(metrics.acceleration)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="100" 
                      value={metrics.acceleration} 
                      onChange={(e) => handleMetricChange('acceleration', parseInt(e.target.value))}
                      className="w-full accent-primary h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Corners</label>
                      <span className="text-xs font-mono text-primary">{Math.round(metrics.corners)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="100" 
                      value={metrics.corners} 
                      onChange={(e) => handleMetricChange('corners', parseInt(e.target.value))}
                      className="w-full accent-primary h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Overspeed Alerts</label>
                      <span className="text-xs font-mono text-accent-red">{metrics.overspeedAlerts}</span>
                    </div>
                    <input 
                      type="range" min="0" max="10" 
                      value={metrics.overspeedAlerts} 
                      onChange={(e) => handleMetricChange('overspeedAlerts', parseInt(e.target.value))}
                      className="w-full accent-accent-red h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Avg G-Force</label>
                      <span className="text-xs font-mono text-accent-green">{metrics.avgGForce.toFixed(1)} G</span>
                    </div>
                    <input 
                      type="range" min="0" max="5" step="0.1"
                      value={metrics.avgGForce} 
                      onChange={(e) => handleMetricChange('avgGForce', parseFloat(e.target.value))}
                      className="w-full accent-accent-green h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Wheel Score Gauge */}
          <div className="col-span-12 lg:col-span-4 bg-surface-dark rounded-xl p-6 flex flex-col items-center justify-center border border-surface-darker relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent"></div>
            </div>
            <h3 className="text-lg font-bold mb-8 flex items-center gap-2">
              Wheel Score
              <BrainCircuit className="w-4 h-4 text-primary" />
            </h3>
            <div className="relative w-48 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={scoreData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    startAngle={90}
                    endAngle={-270}
                    paddingAngle={0}
                    dataKey="value"
                    stroke="none"
                  >
                    <Cell fill="#0da6f2" />
                    <Cell fill="#1e293b" />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-5xl font-black">{predictedScore}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mt-1">Predicted by AI</span>
              </div>
            </div>
            <div className="mt-8 flex gap-6 text-center">
              <div>
                <p className="text-2xl font-bold text-accent-green">{Math.round(metrics.braking)}%</p>
                <p className="text-xs text-slate-500">Braking</p>
              </div>
              <div className="w-px h-8 bg-surface-darker"></div>
              <div>
                <p className="text-2xl font-bold text-primary">{Math.round(metrics.acceleration)}%</p>
                <p className="text-xs text-slate-500">Acceleration</p>
              </div>
              <div className="w-px h-8 bg-surface-darker"></div>
              <div>
                <p className="text-2xl font-bold text-accent-green">{Math.round(metrics.corners)}%</p>
                <p className="text-xs text-slate-500">Corners</p>
              </div>
            </div>
          </div>

          {/* Stats & Behavior */}
          <div className="col-span-12 lg:col-span-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Milestone className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-accent-green text-sm font-bold flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" /> +12%
                  </span>
                </div>
                <p className="text-slate-400 text-sm font-medium">Distance Travelled</p>
                <p className="text-3xl font-black mt-1">1,240 <span className="text-sm font-normal text-slate-500">km</span></p>
              </div>
              <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-2 bg-accent-green/10 rounded-lg">
                    <History className="w-5 h-5 text-accent-green" />
                  </div>
                  <span className="text-accent-green text-sm font-bold flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" /> +8%
                  </span>
                </div>
                <p className="text-slate-400 text-sm font-medium">Number of Rides</p>
                <p className="text-3xl font-black mt-1">156</p>
              </div>
            </div>

            {/* Driving Behavior Chart */}
            <div className="bg-surface-dark p-6 rounded-xl border border-surface-darker h-64 relative overflow-hidden">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold">Driving Behavior (Accelerometer)</h3>
                <div className="flex gap-2">
                  <span className="flex items-center gap-1 text-xs bg-surface-darker px-2 py-1 rounded">
                    <span className="w-2 h-2 rounded-full bg-primary"></span> G-Force
                  </span>
                </div>
              </div>
              <div className="h-40 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={behaviorData}>
                    <defs>
                      <linearGradient id="colorG" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0da6f2" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#0da6f2" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="g" stroke="#0da6f2" strokeWidth={2} fillOpacity={1} fill="url(#colorG)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        {/* Middle Section */}
        <div className="grid grid-cols-12 gap-6 mb-6">
          {/* Overspeed Alerts */}
          <div className="col-span-12 lg:col-span-4 bg-surface-dark rounded-xl p-6 border border-surface-darker flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold">Overspeed Alerts</h3>
              <span className="text-xs bg-red-500/20 text-red-500 px-2 py-1 rounded-full font-bold">3 Today</span>
            </div>
            <div className="space-y-4 overflow-y-auto max-h-80 pr-2 hide-scrollbar">
              {alerts.map((alert, i) => (
                <div key={i} className={cn("p-3 bg-surface-darker/50 rounded-lg flex items-center justify-between border-l-4", alert.type === 'critical' ? 'border-red-500' : 'border-amber-500')}>
                  <div>
                    <p className="text-sm font-bold">{alert.speed} <span className="text-xs font-normal text-slate-500">{alert.zone}</span></p>
                    <p className="text-xs text-slate-400">{alert.loc}</p>
                  </div>
                  <span className="text-xs text-slate-500">{alert.time}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Leaderboard */}
          <div className="col-span-12 lg:col-span-8 bg-surface-dark rounded-xl p-6 border border-surface-darker">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold">City Leaderboard</h3>
              <button className="text-primary text-xs font-bold hover:underline">See All</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-slate-500 text-xs border-b border-surface-darker uppercase tracking-wider">
                    <th className="pb-3 font-medium">Rank</th>
                    <th className="pb-3 font-medium">Driver</th>
                    <th className="pb-3 font-medium">Wheel Score</th>
                    <th className="pb-3 font-medium">Total Rides</th>
                    <th className="pb-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {leaderboard.map((row, i) => (
                    <tr key={i} className={cn("border-b border-surface-darker/50 hover:bg-surface-darker/30 transition-colors", row.active && "bg-primary/5")}>
                      <td className={cn("py-4 font-bold", row.color)}>{row.rank}</td>
                      <td className="py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-slate-700 overflow-hidden">
                            <img src={`https://picsum.photos/seed/driver${i}/100/100`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          </div>
                          <span className={cn(row.active && "font-bold")}>{row.name}</span>
                        </div>
                      </td>
                      <td className="py-4 font-bold">{row.score}</td>
                      <td className="py-4">{row.rides}</td>
                      <td className="py-4">
                        <span className={cn("px-2 py-1 text-[10px] font-bold rounded uppercase", row.status === 'Elite' ? "bg-accent-green/10 text-accent-green" : "bg-primary/10 text-primary")}>
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="grid grid-cols-12 gap-6">
          {/* Coupon Rewards */}
          <div className="col-span-12 lg:col-span-7">
            <h3 className="font-bold mb-4">Available Rewards</h3>
            <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar">
              {[
                { icon: Fuel, title: '20% OFF', desc: 'Next 10 Gallons at Shell', tag: 'Fuel Discount', color: 'from-primary to-blue-600' },
                { icon: Utensils, title: '$15 Voucher', desc: 'Any Drive-Thru Partner', tag: 'Food Perk', color: 'from-accent-green to-emerald-600' },
                { icon: Wrench, title: 'Free Oil Change', desc: 'Elite Tier Maintenance Reward', tag: 'Maintenance', color: 'from-purple-600 to-indigo-600' },
              ].map((reward, i) => (
                <div key={i} className={cn("min-w-[280px] bg-gradient-to-br rounded-xl p-5 text-white flex flex-col justify-between h-40", reward.color)}>
                  <div className="flex justify-between">
                    <reward.icon className="w-8 h-8" />
                    <span className="text-[10px] font-bold bg-white/20 px-2 py-1 rounded uppercase tracking-tighter">{reward.tag}</span>
                  </div>
                  <div>
                    <p className="text-2xl font-black">{reward.title}</p>
                    <p className="text-xs opacity-80">{reward.desc}</p>
                  </div>
                  <button className="w-full py-2 bg-white text-slate-900 font-bold rounded-lg text-xs">Redeem Coupon</button>
                </div>
              ))}
            </div>
          </div>

          {/* Mini Map */}
          <div className="col-span-12 lg:col-span-5 bg-surface-dark rounded-xl border border-surface-darker overflow-hidden flex flex-col">
            <div className="p-4 flex justify-between items-center bg-surface-dark/80 backdrop-blur border-b border-surface-darker">
              <h3 className="font-bold text-sm">Active Navigation</h3>
              <div className="flex items-center gap-1 text-xs text-slate-400">
                <span className="w-2 h-2 rounded-full bg-accent-green animate-pulse"></span>
                Live Traffic
              </div>
            </div>
            <div className="flex-1 min-h-[160px] relative bg-slate-900 overflow-hidden">
              <img 
                src="https://picsum.photos/seed/nyc/600/400" 
                className="w-full h-full object-cover opacity-20 grayscale"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-1/2 left-1/3 w-3 h-3 bg-primary rounded-full shadow-[0_0_15px_rgba(13,166,242,1)] z-10"></div>
              <div className="absolute bottom-4 left-4 right-4 bg-surface-dark/90 p-3 rounded-lg border border-surface-darker flex items-center justify-between z-20">
                <div className="flex items-center gap-3">
                  <NavIcon className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-xs font-bold">2.4 km to destination</p>
                    <p className="text-[10px] text-slate-400">Arrive in 6 mins • JFK Terminal 4</p>
                  </div>
                </div>
                <button className="p-2 bg-surface-darker rounded-lg text-slate-400">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
